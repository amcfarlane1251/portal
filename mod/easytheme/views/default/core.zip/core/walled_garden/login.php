<?php
/**
 * Walled garden login
 */
?>
<style>
.elgg-inners .idbutton{
	margin: 81px 0px 0px 11px;
	font-size: 14px;
	color: #136ABB;
	font-weight: bold;
	border: 1px solid #999;
	border-radius: 5px;
	width: auto;
	padding: 3px 6px;
	cursor: pointer;
	outline: none;
	background: #CCC url(http://198.164.43.9/elgg/_graphics/button_background.gif) repeat-x 0 0;
	-webkit-box-shadow: 0px 1px 0px rgba(0, 0, 0, 0.40);
	-moz-box-shadow: 0px 1px 0px rgba(0, 0, 0, 0.40);
	box-shadow: 0px 1px 0px rgba(0, 0, 0, 0.40);	
}
.elgg-inners .idbutton:hover{
	text-shadow: 1px 1px 0px black;
	color:white;
	text-decoration: none;
	border: 1px solid #4690D6;
	background: #4690D6 url(http://198.164.43.9/elgg/_graphics/button_graduation.png) repeat-x left 10px;
}
</style>
<?php
$title = elgg_get_site_entity()->name;
$welcome = elgg_echo('walled_garden:welcome');
$welcome .= ': <br/>' . $title;

$menu = elgg_view_menu('walled_garden', array(
	'sort_by' => 'priority',
	'class' => 'elgg-menu-general elgg-menu-hz',
));

$login_box = elgg_view('core/account/login_box', array('module' => 'walledgarden-login'));
$req =  elgg_view('input/submit', array('value' => elgg_echo('Request an ONGARDE Account')));

echo <<<HTML
<div class="elgg-col elgg-col-1of2">
	<div class="elgg-inner">
		<h1 class="elgg-heading-walledgarden">
			$welcome
		</h1>
		$menu
	</div>
	<div class="elgg-inners">
		<a href="mailto:CDA-ADLLab@forces.gc.ca"><button type="submit" class="idbutton" >Request an ONGARDE account</button></a>
	</div>
</div>
<div class="elgg-col elgg-col-1of2">
	<div class="elgg-inner">
		$login_box
	</div>

</div>
HTML;
