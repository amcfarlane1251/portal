
<style>
ul.gs {
	list-style-type: none;
	margin-left: 30px;
}
li.dsc a {
	width: 80px;
	padding-right: 80px;
	padding-bottom: 50px;

}
li.grp a {
	width: 80px;
	padding-right: 80px;
	padding-bottom: 50px;
}
li.blg a {
	width: 80px;
	padding-right: 80px;
	padding-bottom: 50px;
}
li.fle a {
	width: 80px;
	padding-right: 80px;
	padding-bottom: 50px;
}
li.qtn a {
	width: 80px;
	padding-right: 80px;
	padding-bottom: 50px;
}
li.mbr a {
	width: 80px;
	padding-right: 80px;
	padding-bottom: 50px;
}
ul.gs li {
	display: inline-block;
	/*width: 100px;*/
	height: 50px;	
	margin-right: 3px;
	margin-bottom:10px;
}
/*
.gs, .grp, .blg, .fle, .qtn, .mbr {
	background: url(<?php echo elgg_get_site_url(); ?>mod/cool_theme/_graphics/gs_sprite.png) no-repeat;
}
*/
ul li.dsc {

	background-image:url(<?php echo elgg_get_site_url(); ?>mod/cool_theme/_graphics/discussion.png);
}
ul li.dsc:hover {
	background-image:url(<?php echo elgg_get_site_url(); ?>mod/cool_theme/_graphics/discussion_hover.png);	
}
ul li.grp {

	background-image:url(<?php echo elgg_get_site_url(); ?>mod/cool_theme/_graphics/group.png);
}
ul li.grp:hover {
	background-image:url(<?php echo elgg_get_site_url(); ?>mod/cool_theme/_graphics/group_hover.png);	
}
ul li.blg {

	background-image:url(<?php echo elgg_get_site_url(); ?>mod/cool_theme/_graphics/blog.png)
}
ul li.blg:hover {
	background-image:url(<?php echo elgg_get_site_url(); ?>mod/cool_theme/_graphics/blog_hover.png)	
}
ul li.fle {

	background-image:url(<?php echo elgg_get_site_url(); ?>mod/cool_theme/_graphics/file.png)
}
ul li.fle:hover {
	background-image:url(<?php echo elgg_get_site_url(); ?>mod/cool_theme/_graphics/file_hover.png);	
}
ul li.qtn {

	background-image:url(<?php echo elgg_get_site_url(); ?>mod/cool_theme/_graphics/question.png);
}
ul li.qtn:hover {
	background-image:url(<?php echo elgg_get_site_url(); ?>mod/cool_theme/_graphics/question_hover.png);	
}
ul li.mbr {

	background-image:url(<?php echo elgg_get_site_url(); ?>mod/cool_theme/_graphics/member.png);
}
ul li.mbr:hover {
	background-image:url(<?php echo elgg_get_site_url(); ?>mod/cool_theme/_graphics/member_hover.png);
}



</style>


<!-- <ul class="gs">
<li class="dsc"><a href="https://www.google.ca/"></a></li>
<li class="grp"><a href=""></a></li>
<li class="blg"><a href=""></a></li>
<li class="fle"><a href=""></a></li>
<li class="qtn"><a href=""></a></li>
<li class="mbr"><a href=""></a></li>
</ul><br /> -->

<div class="elgg-composer"><h4><?php echo elgg_echo('composer:prompt'); ?> :</h4><?php 
		echo elgg_view_menu('composer', array(
			'entity' => elgg_get_page_owner_entity(),
			'class' => 'elgg-menu-hz',
			'sort_by' => 'priority',
		));
	?></div><script>$('.elgg-composer').tabs({spinner: '',panelTemplate: '<div><div class="elgg-ajax-loader"></div></div>'});</script>